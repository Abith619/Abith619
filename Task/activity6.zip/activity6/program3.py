 
def hexadecimalToDecimal(hexval):
 
    length = len(hexval)

    base = int(input("Enter a value:"))
    dec_val = int(input("Enter a number:"))
 
    for i in range(length - 1, -1, -1):
 
        if hexval[i] >= '0' and hexval[i] <= '9':
            dec_val += (ord(hexval[i]) - 48) * base
            base = base * 16
        elif hexval[i] >= 'A' and hexval[i] <= 'F':
            dec_val += (ord(hexval[i]) - 55) * base
 
            base = base * 16
    return dec_val
    
if __name__ == '__main__':
 
    hexnum = '1A'
 
    print(hexadecimalToDecimal(hexnum))
