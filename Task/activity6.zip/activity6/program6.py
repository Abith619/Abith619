def is_sorted(list_of_numbers):
    if sorted(list_of_numbers) == list_of_numbers:
        return True
  
    elif sorted(list_of_numbers, key=int, reverse=True) == list_of_numbers:
        return True
  
    return False
 
def main():
    list_of_numbers = []
    
    done = False
    while not done:
        number = int(input("Enter a number. Exit with 0: "))
        if number != 0:
            list_of_numbers.append(number)
        else:
            done = True
    print(is_sorted(list_of_numbers))
 
if __name__ == '__main__':
    main()