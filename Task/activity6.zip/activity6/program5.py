

1
from   random    import    randrange

MIN_NUM  = int(input("Enter a min number:"))
MAX_NUM  = int(input("Enter a max number:"))
NUM_NUMS   = int(input("Enter a number:"))
ticket_nums = []

for   i  in  range (NUM_NUMS):
   rand = randrange(MIN_NUM,         MAX_NUM    +  1)
   while    rand   in  ticket_nums:
      rand = randrange(MIN_NUM,         MAX_NUM    +  1)
   ticket_nums.append(rand)
ticket_nums.sort()
print ("Your      numbers    are:   ",  end="")
for   n  in  ticket_nums:
   print (n,    end="    ")
print ()