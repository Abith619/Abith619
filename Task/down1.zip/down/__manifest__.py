{
    'name': 'Hotel Record',
'summary': """This module will add a record to store Hotel details""",
'version': '0.1',
'description': """This module will add a record to store Hotel details"""
,'author': 'Abith',
'company': 'Xmedia Solutions',
'website': 'https://www.xmedia.in',
'category': 'Tools',
'depends': ['base','web','mail','contacts','account','kanban_draggable', "sale"],
'license': 'AGPL-3',

'data': ['security/ir.model.access.csv',
    'views/master_floor.xml',
    'views/master_room.xml',
    'views/invoice.xml',
    # 'reports/.xml',
    # 'reports/.xml',
    ],
    'demo': [],
    'installable': True,
    'auto_install': True,
}