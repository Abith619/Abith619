from odoo import models, fields, api
from odoo.exceptions import ValidationError
import logging, datetime, random

class HotelBooking(models.Model):
    _name="floor"
    _inherit=('mail.thread', 'mail.activity.mixin')
    name = fields.Many2one('res.partner',string='Name', required=True) 
    names = fields.Many2one('res.users')
    bill_no = fields.Char(string="Service Number", readonly=True, required=True, copy=False, default='New')  
    # total1=fields.Integer(string='TotalAmount', )

#        States 
    state =fields.Selection([
        ('draft','Draft'),('cancell','Cancelled'),
        ('confirm','Confirmed')],string='Status',default='draft')

#       Generate Sequence in Invoice S.no
    @api.model
    def create(self, vals):
        if vals.get('bill_no', 'New') == 'New':
            vals['bill_no'] = self.env['ir.sequence'].next_by_code('self.service') or 'New'
        result = super(HotelBooking,self).create(vals)
        return result

#                               Invoice
    def print_invoice(self):
            return{
        'name': "Paid ",
        'type': 'ir.actions.act_window',
        'view_type': 'form',
        'view_mode': 'form',
        'res_model': 'account.invoice',
        'view_id': self.env.ref('account.invoice_form').id,
        'context': {
            'default_partner_id': self.name.id,
        },
        'target': 'new'
    }

#                       State-Confirm
    def confirm(self):
        for rec in self:
            rec.state='confirm'
#                       State-Cancell
    def cancell(self):
        for rec in self:
            rec.state='cancell'

#                               Send E-Mail 
    def action_send_email(self):
        self.ensure_one()
        compose_form_id = False
        return {
        'name': 'Compose Email',
        'type': 'ir.actions.act_window',
        'view_mode': 'form',
        'res_model': 'mail.compose.message',
        'views': [(compose_form_id, 'form')],
        'view_id': compose_form_id,
        'target': 'new',
    }
#                         One2Many - Line
    select_room=fields.One2many('floor.line','y_name')

    total1 = fields.Float(string='Total', store=True)

    # @api.depends('amount','tax')
    @api.onchange('select_room.y_name')
    def _get_s(self):
        raise ValidationError("Please provide valid age  ?")
        for rec in self:
            rec.update({
                'total': rec.amount + sum(tax.amount for tax in rec.tax)
            })
    

class HotelLine(models.Model):
    _name="floor.line"
    floors=fields.Selection([('1','1st Floor'),('2','2nd Floor'),('3','3rd Floor')],string='Floor', required=True) 
    y_name=fields.Many2one('floor',string='Name')
    amount=fields.Float(string="Price")
    tax=fields.Many2many("account.tax",string="Tax")
    room_type=fields.Selection([('S','Standard'),('P','Premium')],string='Room Type', required=True)
    check_in=fields.Datetime(string="Check In")
    check_out=fields.Datetime(string="Check Out")
    total = fields.Float(string='Total', store=True,compute='_get_sum')
#    Add Total
    @api.depends('amount','tax')
    def _get_sum(self):
        for rec in self:
            rec.update({
                'total': rec.amount + sum(tax.amount for tax in rec.tax)
            })