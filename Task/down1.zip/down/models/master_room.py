from odoo import models, fields, api

class Rooms(models.Model):
    _name="room"
    _inherit='floor.line'
    name = fields.Char(string='Name', required=True)
    conf_room=fields.selection([('121'),('122'),('123')])

class RoomTypes(models.Model):
    _name="room.type"
    conference_room=fields.Many2one('conf_room', string='Conference Room')
    meeting_room=fields.Many2one('',string='Meeting Room')
    living_room=fields.Many2one('',string='Living Room')