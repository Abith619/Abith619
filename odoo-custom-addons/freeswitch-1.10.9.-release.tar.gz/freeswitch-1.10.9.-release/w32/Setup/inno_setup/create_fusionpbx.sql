CREATE USER 'fusionpbx'@'localhost' IDENTIFIED BY 'fusionpbx';
GRANT ALL ON *.* TO 'fusionpbx'@'localhost';

