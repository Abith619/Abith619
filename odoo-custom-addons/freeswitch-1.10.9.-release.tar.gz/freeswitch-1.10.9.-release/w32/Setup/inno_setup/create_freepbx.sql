CREATE USER 'freepbx'@'localhost' IDENTIFIED BY 'freepbx';
GRANT ALL ON *.* TO 'freepbx'@'localhost';
