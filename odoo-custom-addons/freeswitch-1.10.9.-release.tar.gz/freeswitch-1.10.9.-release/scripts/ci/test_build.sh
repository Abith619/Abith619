#!/bin/bash
./bootstrap.sh -j
./configure -C
make
