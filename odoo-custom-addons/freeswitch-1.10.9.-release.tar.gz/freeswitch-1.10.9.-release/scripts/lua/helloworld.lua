-- Simple answer and playback lua example
session:answer();
session:streamFile("blah.wav");
session:hangup();
